//
//  Valor.swift
//
//  AppDelegate.swift

//  Created by Ruben Salas.
//  Copyright © 2017 Ruben Salas. All rights reserved.
//

import WatchKit

class Valor: NSObject {
    var tamano: String? = nil
    var masa: String? = nil
    var queso: String? = nil
    var ingredientes: [String] = []
    
    override init() {
    }
    init(valor: Valor) {
        self.tamano = valor.tamano
        self.masa = valor.masa
        self.queso = valor.queso
        self.ingredientes = valor.ingredientes
    }
}
