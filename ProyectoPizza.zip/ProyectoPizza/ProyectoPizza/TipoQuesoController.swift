//
//  TipoQuesoController.swift
//  ProyectoPizza
//
//  Created by Ruben Salas on 3/4/17.
//  Copyright © 2017 Didactica. All rights reserved.
//

import UIKit

class TipoQuesoController: UIViewController {
    var tamanoPizza: String? = nil
    var tipoMasa: String? = nil
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.title="Tipo de Queso"
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        let boton = sender as! UIButton
        let resultado: String = boton.titleLabel!.text!
        print(resultado)
        let sigVista = segue.destinationViewController as! IngredientesController
        sigVista.tamanoPizza = self.tamanoPizza
        sigVista.tipoMasa = self.tipoMasa
        sigVista.tipoQueso = resultado
    }
}
