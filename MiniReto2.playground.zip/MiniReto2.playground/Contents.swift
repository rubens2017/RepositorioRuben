//: Playground - noun: a place where people can play

import UIKit



for i in 0 ..< 101 {
    
    if i % 5 == 0 {
        
        print (i,"BINGO!!!")
        
    }else if i % 2 == 0 {
        
        print (i,"PAR!!!")
    }else if i % 2 != 0{
        
        print (i,"IMPAR!!!")
        
        
    }
    
    if i >= 30 && i <= 40 {
        
        print(i,"VIVA SWIFT")
        
    }
    
    
    
}

