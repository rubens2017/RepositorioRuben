//
//  Valor.swift
//  ProyectoPizzaAW
//
//  Created by Adrian Orozco on 3/18/17.
//  Copyright © 2017 Didactica. All rights reserved.
//

import WatchKit

class Valor: NSObject {
    var tamano: String? = nil
    var masa: String? = nil
    var queso: String? = nil
    var ingredientes: [String] = []
    
    override init() {
    }
    init(valor: Valor) {
        self.tamano = valor.tamano
        self.masa = valor.masa
        self.queso = valor.queso
        self.ingredientes = valor.ingredientes
    }
}
