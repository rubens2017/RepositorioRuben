//
//  Datos.swift
//  HamburguesasPorElMundo
//
//  Created by Adrian Orozco on 12/31/16.
//  Copyright © 2016 Didactica. All rights reserved.
//

import Foundation
import UIKit

struct Colores {
    let colores = [ UIColor(red:210/255.0, green: 90/255.0, blue: 45/255.0, alpha: 1),
                    
                    UIColor(red:40/255.0, green: 170/255.0, blue: 45/255.0, alpha: 1),
                    
                    UIColor(red:3/255.0, green: 180/255.0, blue: 90/255.0, alpha: 1),
                    
                    UIColor(red:210/255.0, green: 190/255.0, blue: 5/255.0, alpha: 1),
                    
                    UIColor(red:120/255.0, green: 120/255.0, blue: 50/255.0, alpha: 1),
                    
                    UIColor(red:130/255.0, green: 80/255.0, blue: 90/255.0, alpha: 1),
                    
                    UIColor(red:130/255.0, green: 130/255.0, blue: 130/255.0, alpha: 1),
                    
                    UIColor(red:3/255.0, green: 50/255.0, blue: 90/255.0, alpha: 1)]
    
    
    func regresaColorAleatorio() ->UIColor{
        let posicion = Int ( arc4random()) % colores.count
        return colores[posicion]
        
    }
    
    
    
}

struct ColeccionDePaises {
    
    let paises = ["Costa Rica",
                  "México",
                  "Estados Unidos",
                  "Alemania",
                  "Francia",
                  "Italia",
                  "China",
                  "Japón",
                  "Corea del Sur",
                  "Nigeria",
                  "Camerún",
                  "Sudafrica",
                  "Argentina",
                  "Brasil",
                  "Paraguay",
                  "Australia",
                  "Honduras",
                  "Panamá",
                  "Guatemala",
                  "Canadá"]
    
    func obtenPais() -> String{
        let posicion = Int ( arc4random()) % paises.count
        return paises[posicion]
        
    }
}

struct ColeccionDeHamburguesas {
    
    let hamburguesas = ["Hamburguesa de frijoles y salsa lizano",
                  "Hamburguesa picante con frijoles y chile",
                  "Hamburguesa con queso y cebollas extras",
                  "Hamburguesa con salchicha y salsa especial",
                  "Hamburguesa con filet mignon",
                  "Hamburguesa con salsa italiana y albondigas",
                  "Hamburguesa con salsa china especial",
                  "Hamburguesa sushi",
                  "Hamburguesa con vegetales hervidos",
                  "Hamburguesa con carne de res",
                  "Hamburguesa con carne de vaca",
                  "Hamburguesa con petipoas",
                  "Hamburguesa con asado y cebollas",
                  "Hamburguesa Guaraná",
                  "Hamburguesa con chile dulce",
                  "Hamburguesa con carne de canguro",
                  "Hamburguesa con carne asada a la parrilla",
                  "Hamburguesa con carne y chile panameño",
                  "Hamburguesa con carne de bufalo",
                  "Hamburguesa con tocineta extra"]
    
    func obtenHamburguesa() -> String{
        let posicion = Int ( arc4random()) % hamburguesas.count
        return hamburguesas[posicion]
        
    }
}


