//
//  ViewController.swift
//  ProyectoPizza
//
//  Created by Ruben Salas on 3/4/17.
//  Copyright © 2017 Didactica. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        self.title = "Tamaño de la Pizza";
        
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        let boton = sender as! UIButton
        let resultado: String = boton.titleLabel!.text!
        print(resultado)
        let sigVista = segue.destinationViewController as! TipoMasaController
        sigVista.tamanoPizza = resultado
    }



}

