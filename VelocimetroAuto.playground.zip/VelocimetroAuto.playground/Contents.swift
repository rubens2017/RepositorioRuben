//: Mini Reto 2 : Velocímetro de Automóvil
//: Autor: Rubén Salas

import UIKit

class Auto {
    
    
    
    enum Velocidades : Int{
        
        
        case apagado = 0, velocidadbaja = 20, velocidadmedia = 50, velocidadalta = 120
        
        
        init(VelocidadInicial : Velocidades){
            
            self = .apagado
            
        }
        
    }
    
    
    
    
    
    
    func cambioDeVelocidad(actual : Int, VelocidadesEnCadena : String) -> (actual2: Int, velocidadnueva: String) {
        
        var velocidadnew = 0
        var mensaje = ""
        
        if (actual == 0) {
            velocidadnew = Velocidades.apagado.rawValue
            mensaje = "Apagado"
            
        }else if (actual * 20 == 20){
            velocidadnew = Velocidades.velocidadbaja.rawValue
            mensaje = "Velocidad Baja"
        } else if (actual % 2 == 0){
            velocidadnew = Velocidades.velocidadmedia.rawValue
            mensaje = "Velocidad Media"
        }else if (actual % 2 != 0){
            velocidadnew = Velocidades.velocidadalta.rawValue
            mensaje = "Velocidad Alta"
        }
        
        let resultado = (velocidadnew, mensaje)
        
        return resultado
    }
    
    
}


var velocidad = Auto()


for i in 0 ..< 20 {
    
    print (velocidad.cambioDeVelocidad(i, VelocidadesEnCadena: ""))
    
}
